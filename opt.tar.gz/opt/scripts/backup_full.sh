#!/bin/bash

#Ubicacion_script: /opt/scripts/backup_full.sh
#Descripcion: Realiza backups de directorios
#Ejemplo: backup_full.sh [-help] <origen> <destino>

mostrar_ayuda() {
    echo "Modo de uso:  backup_full.sh [-help] <origen> <destino>"
    echo ""
    echo "Script que realiza backups de directorios especificos con fecha en formato ANSI (YYYYMMDD)"
    echo "Opciones:"
    echo " -help imprime ayuda"
}

if [ "$1" == "-help" ]; then
    mostrar_ayuda
    exit 0
fi 

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE_BKP=$(basename $ORIGEN)_bkp_$FECHA.tar.gz 

if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe"
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe"
    exit 1
fi

echo "Iniciando backup... $ORIGEN ---> $DESTINO/$NOMBRE_BKP"
tar -czf $DESTINO/$NOMBRE_BKP $ORIGEN

echo "Chequeando si el backup fue exitoso..."
if [ $? -eq 0 ]; then
    echo "Backup completado exitosamente: $DESTINO/$NOMBRE_BKP" 
    exit 0
else
    echo "Error: Fallo al crear el backup."
    exit 1 
fi
